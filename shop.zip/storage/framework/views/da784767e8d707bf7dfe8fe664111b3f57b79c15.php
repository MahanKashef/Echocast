<?php echo $__env->make('Together.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


@yeild('content')


<?php echo $__env->make('Together.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH T:\PHP\php\shop\resources\views/Together/main.blade.php ENDPATH**/ ?>