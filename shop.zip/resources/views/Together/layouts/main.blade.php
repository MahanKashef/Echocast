@include('Together.layouts.header')

@yield('content')

@include('Together.layouts.footer')