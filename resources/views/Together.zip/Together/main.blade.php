@include('Together.layouts.header')


@yeild('content')


@include('Together.layouts.footer')