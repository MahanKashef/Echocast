@extends('Together.layouts.main')


@section('content')
    

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@1,900&display=swap" rel="stylesheet">
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600&display=swap" rel="stylesheet">

    <script src="https://kit.fontawesome.com/90d90f8831.js" crossorigin="anonymous"></script>

     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

    <link rel="stylesheet" href="/css/Archive.css">

    <!-- Media Queries -->

    <link rel="stylesheet" href="/css/media/archive.media.css">


</head>
<body>

    <main>
        <div class="container">
            <div class="head-tag">
                <h2 class="headtag-text">بازار زیبای ارزهای دیجیتال</h2>
                <hr>
                <div class="pictures">
                    <img src="img/1328418482-parsnaz-ir.jpg" alt="banner" class="headtag-img">
                    <img src="img/parsnaz.ir.jpg" alt="picture" class="person-img">
                </div>
            </div>

            

            <div class="person">
                <div class="person-info">
                    <ul class="person-items">
                        <li class="person-item">
                            <i class="fas fa-user-alt"></i>
                            <span>:</span>
                            <span>ماهان کاشف</span>
                        </li>
                        <li class="person-item">
                            <i class="fas fa-briefcase"></i>
                            <span>:</span>
                            <span>مدیرعامل شرکت فناورگستر</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="between">
                <span class="space"></span>
            </div>
            <div class="content">
                <h3 class="content-head">: خلاصـــــــه</h3>
                <p class="content-text"> تخفیف های منطقی. در عین حال متهم یا غیر از این ، من به برخی از مشکلات ، غم و اندوه از کل موضوع ، اما با این حال ، هیچ کس؟ در برخی از لذت های کوچک یا به دلیل درد. این خطایی است که من می آیم ، کاوشگر مورد پذیرفته شده ، نه؟ دردسر سازنده اصلی یک باره زحمتی را می کشد که نتیجه آن بیشتر از لذت درد خواهد بود! شایسته ترین کار خوشحال اگر برخی از قدیمی ها اجتناب شود. گزینه ها تفاوت دارند ، اما به دنبال آن هستند. ما پیامدهای آن را متهم می کنیم و در عین حال ، چیز بزرگ مطرود را دریافت می کنیم؟ پرواز کوتاه تر؟ در این مرحله ، بدن موظف است با کانتیکل ها ستایش کند ، به آنها گفت که او کار کل را رد می کند؟ برای این ارائه ها انتخاب شده است ، از وظایفی که از همان موارد مشابه دنبال می شود ، باید از بعضی موارد خاص پیروی کند. به عنوان مثال ، به عنوان مثال ، تقبیح او در صورت دریافت ، مگر اینکه در آنجا متولد شود ، با این حال ، آنها ناراحتی عمومی را که او از آنها متنفر است ، ترک کردند و به دنبال این مرد رفتند! چون نه. انتخاب زمان ، درد ما آسان است ، که من توضیح می دهم ، کسی که من بیایم به همین دلیل است. برای حال حاضر انتخاب شده است ، ما ممکن است قادر به رد کردن بسیاری از هیچ فرصتی برای فرار نیست ، خود ، خود ، هیچ چیزی برای عیب جویی از زحمت ، و در همان نفرت از حقیقت ، بیش از همه ، همه درد ناشی از انتخاب آنه</p>
            </div>
            <div class="audio">
                <audio controls>
                    <source src="/audio/Demons.mp3" type="audio/ogg">
                    <source src="/audio/Demons.mp3" type="audio/mpeg">
                    <source src="/audio/Demons.mp3" type="audio/wav">
                    سیستم شما توانایی خواندن این فایل را ندارد
                </audio>
            </div>
        </div>
    </main>

       <!-- Suggestion -->

       <section id="suggest">
        <div class="container">
            <h2 class="suggest-head">نظرات و پیشنهادات</h2>
            <div class="users">
                <div class="user">
                    <h4 class="username">ماهان</h4>
                    <p class="user-suggest">این پست یکی از بهترینای تاریخ بود خیلی لذت بردم</p>
                </div>

                <div class="user">
                    <h4 class="username">سعید</h4>
                    <p class="user-suggest">واقعا لذت بردم به شدت مشتاق برنامه های دیگتون هستم</p>
                </div>


                <div class="user">
                    <h4 class="username">جواد</h4>
                    <p class="user-suggest">مامان بیا منو بشور دیگه </p>
                </div>
            </div>
        </div>
    </section>

</body>
</html>


@endsection