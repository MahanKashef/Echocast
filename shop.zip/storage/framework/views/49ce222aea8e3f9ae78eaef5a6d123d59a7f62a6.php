<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        nav{
            width: 100%;
        }
        .container{
            width: 100%;
            background-color: rgba(0,0,0,0.5);
            display: flex;
            justify-content: space-around;
            padding:50px;
        }

        .logo{
            font-size:25px;
        }

        .string{
            color:white;
            font-size:25px;
        }

    </style>
</head>
<body>
    <nav>
        <div class="container">
            <div class="logo">
                <?php echo $logo; ?>
            </div>
            <div class="string">
                <?php 
                    foreach($rows as $row)
                    {
                        echo $row;
                    }
                ?>
            </div>
        </div>
    </nav>
</body>
</html><?php /**PATH T:\PHP\php\shop\resources\views/nav.blade.php ENDPATH**/ ?>