<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>

        .container{
            width: 85%;
            background-color: rgba(0,0,0,0.5);
            margin:0 auto;
        }

        .boxes{
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .box1{
            width: 250px;
            height: 250px;
            background-color: yellow;
            margin:10px 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="boxes">
                <div class="box1">
                </div>
                <div class="box1"></div>
                <div class="box1"></div>
                <div class="box1"></div>
                <div class="box1"></div>
                <div class="box1"></div>
                <div class="box1"></div>
                <div class="box1"></div>
                <div class="box1"></div>

                <?php foreach($posts as $post) { ?>

                    <h1><?php echo $post->title; ?></h1>
                    <p><?php  echo $post->content;?></p>

                <?php } ?>

            </div>
        </div>
    </header>

    <nav>
        <div class="container">
            <?php echo $logo;?>
            <?php echo $array; ?>
        </div>
    </nav>
</body>
</html><?php /**PATH T:\PHP\php\shop\resources\views/post.blade.php ENDPATH**/ ?>