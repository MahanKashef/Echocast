<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/about-us.css">
    <title>About us</title>
</head>
<body>
    <!-- container -->
    <div id="main">
        <header>
            <!-- Nav-Bar -->
        <nav>
            <div class="logo">LOGO</div>
            <div class="menu">
                <ul>
                    <li><a href="/about-us" class="text-animated">About Us</a></li>
                    <li><a href="/" class="text-animated">Home</a></li>
                </ul>
            </div>
        </nav>
        <!-- Nav-Bar End     -->
        
    </header>
        <!-- Card -->
        <div class="card-box">
            <div class="container">
                <div class="wrapper">
                  <a href="#">
                    <img src="#" alt="">
                  </a>
                  <div class="title">
          Andrew Neil</div>
          <div class="place">
          Surkhet, Nepal</div>
          </div>
          <div class="content">
                  <p>
          User Interface Designer and <br>front-end developer</p>
          <div class="buttons">
                    <div class="btn">
                      <button>Message</button>
                    </div>
          <div class="btn">
                      <button>Following</button>
                    </div>
          </div>
          </div>
          <div class="icons">
          <li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
          <li><a href="#"><span class="fab fa-twitter"></span></a></li>
          <li><a href="#"><span class="fab fa-instagram"></span></a></li>
          </div>
          </div>
          <script>
                const img = document.querySelector("img");
                const icons = document.querySelector(".icons");
                img.onclick = function(){
                  this.classList.toggle("active");
                  icons.classList.toggle("active");
                }
              </script>

<div class="container">
    <div class="wrapper">
      <a href="#">
        <img src="#" alt="">
      </a>
      <div class="title">
Andrew Neil</div>
<div class="place">
Surkhet, Nepal</div>
</div>
<div class="content">
      <p>
User Interface Designer and <br>front-end developer</p>
<div class="buttons">
        <div class="btn">
          <button>Message</button>
        </div>
<div class="btn">
          <button>Following</button>
        </div>
</div>
</div>
<div class="icons">
<li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
<li><a href="#"><span class="fab fa-twitter"></span></a></li>
<li><a href="#"><span class="fab fa-instagram"></span></a></li>
</div>
</div>
<script>
    const img = document.querySelector("img");
    const icons = document.querySelector(".icons");
    img.onclick = function(){
      this.classList.toggle("active");
      icons.classList.toggle("active");
    }
  </script>

<div class="container">
    <div class="wrapper">
      <a href="#">
        <img src="#" alt="">
      </a>
      <div class="title">
Andrew Neil</div>
<div class="place">
Surkhet, Nepal</div>
</div>
<div class="content">
      <p>
User Interface Designer and <br>front-end developer</p>
<div class="buttons">
        <div class="btn">
          <button>Message</button>
        </div>
<div class="btn">
          <button>Following</button>
        </div>
</div>
</div>
<div class="icons">
<li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
<li><a href="#"><span class="fab fa-twitter"></span></a></li>
<li><a href="#"><span class="fab fa-instagram"></span></a></li>
</div>
</div>
<script>
    const img = document.querySelector("img");
    const icons = document.querySelector(".icons");
    img.onclick = function(){
      this.classList.toggle("active");
      icons.classList.toggle("active");
    }
  </script>

<div class="container">
    <div class="wrapper">
      <a href="#">
        <img src="#" alt="">
      </a>
      <div class="title">
Andrew Neil</div>
<div class="place">
Surkhet, Nepal</div>
</div>
<div class="content">
      <p>
User Interface Designer and <br>front-end developer</p>
<div class="buttons">
        <div class="btn">
          <button>Message</button>
        </div>
<div class="btn">
          <button>Following</button>
        </div>
</div>
</div>
<div class="icons">
<li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
<li><a href="#"><span class="fab fa-twitter"></span></a></li>
<li><a href="#"><span class="fab fa-instagram"></span></a></li>
</div>
</div>
<script>
    const img = document.querySelector("img");
    const icons = document.querySelector(".icons");
    img.onclick = function(){
      this.classList.toggle("active");
      icons.classList.toggle("active");
    }
  </script>


        </div>
        <!-- About-US Box -->
        <div class="T-box">
            <p class="h1">About us</p>
            <hr>
            <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti vitae ad et distinctio, eum voluptatem voluptatum unde nihil recusandae dolorem animi laboriosam assumenda consequatur fugiat cum, tempora praesentium, velit officia.</p>
        </div>
        <!-- About-US Box END -->

        
   

    </div>







    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    
</body>
</html><?php /**PATH T:\PHP\php\shop\resources\views/about-us.blade.php ENDPATH**/ ?>