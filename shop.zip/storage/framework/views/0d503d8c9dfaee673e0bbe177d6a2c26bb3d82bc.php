<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="products/store" method="Post" enctype="multipart/form-data">
        <!-- Add CSRF Token -->
        <?php echo csrf_field(); ?>;
        <div class="form-group">
            <label>Image Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="form-group">
            <input type="file" name="file" required>
        </div>

        <button type="submit">Submit</button>
    </form>
</body>
</html><?php /**PATH T:\PHP\php\shop\resources\views/test.blade.php ENDPATH**/ ?>