<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class DashboardController extends Controller
{
    public function index()
    {
        $userCount = DB::table('users')->count();
        $commentCount = DB::table('comments')->count();
        $podcastCount = DB::table('podcasts')->count();
        $guestCount = DB::table('guests')->count();
        return view('Together.admin.dashboard.index')->with(['userCount'=>$userCount , 'commentCount'=>$commentCount , 'podcastCount'=>$podcastCount , 'guestCount'=>$guestCount]);
    }
}
