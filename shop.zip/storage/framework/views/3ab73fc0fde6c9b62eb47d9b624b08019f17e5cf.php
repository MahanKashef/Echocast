

<?php $__env->startSection('content'); ?>
    

        <section class="pt-3 pb-1 mb-2 border-bottom">
    <h1 class="h5">Login</h1>
</section>

<section class="row my-3">
    <section class="col-12">

      <!--  <form method="post" action="http://localhost/Lasting_flavors/podcast/store" enctype="multipart/form-data" > -->
        <form method="post" action="/admin/user/check" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email"  class="form-control" id="email" name="email" placeholder="Email ..." rows="3" required autofocus>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Password ..." required autofocus>
            </div>

            <button type="submit" class="btn btn-primary btn-sm">store</button>
        </form>
    </section>
</section>







  <?php if(session()->has('message')): ?>
  <div class="alert <?php echo e(session('alert') ?? 'alert-danger'); ?>">
      <?php echo e(session('message')); ?>

  </div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Together.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH T:\PHP\php\shop\resources\views/Together/admin/users/login.blade.php ENDPATH**/ ?>