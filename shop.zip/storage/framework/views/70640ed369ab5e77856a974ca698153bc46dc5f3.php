<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@1,900&display=swap" rel="stylesheet">
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600&display=swap" rel="stylesheet">

    <script src="https://kit.fontawesome.com/90d90f8831.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="/css/Archive.css">

    <!-- Media Queries -->

    <link rel="stylesheet" href="/media/archive.media.css">


</head>
<body>

    <nav>
        <div class="logo">LOGO</div>
        <input type="checkbox" id="check">
        <label class="menu-bar" for="check">
            <i class="fas fa-bars"></i>
        </label>
        <div class="menu">
            <ul>
                <li><a href="/" class="text-animated">Home</a></li>
                <li><a href="/Archive" class="here text-animated">Archive</a></li>
                <li><a href="/About-us" class="text-animated">About</a></li>
                <li><a href="#" class="text-animated">Contact</a></li>
            </ul>
        </div>
        </nav>

    <main>
        <div class="container">
            <div class="head-tag">
                <h2 class="headtag-text">بازار زیبای ارزهای دیجیتال</h2>
                <hr>
                <div class="pictures">
                    <img src="img/1328418482-parsnaz-ir.jpg" alt="banner" class="headtag-img">
                    <img src="img/parsnaz.ir.jpg" alt="picture" class="person-img">
                </div>
            </div>
            <div class="person">
                <div class="person-info">
                    <ul class="person-items">
                        <li class="person-item">
                            <i class="fas fa-user-alt"></i>
                            <span>:</span>
                            <span>ماهان کاشف</span>
                        </li>
                        <li class="person-item">
                            <i class="fas fa-briefcase"></i>
                            <span>:</span>
                            <span>مدیرعامل شرکت فناورگستر</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="between">
                <span class="space"></span>
            </div>
            <div class="content">
                <h3 class="content-head">: خلاصـــــــه</h3>
                <p class="content-text"> تخفیف های منطقی. در عین حال متهم یا غیر از این ، من به برخی از مشکلات ، غم و اندوه از کل موضوع ، اما با این حال ، هیچ کس؟ در برخی از لذت های کوچک یا به دلیل درد. این خطایی است که من می آیم ، کاوشگر مورد پذیرفته شده ، نه؟ دردسر سازنده اصلی یک باره زحمتی را می کشد که نتیجه آن بیشتر از لذت درد خواهد بود! شایسته ترین کار خوشحال اگر برخی از قدیمی ها اجتناب شود. گزینه ها تفاوت دارند ، اما به دنبال آن هستند. ما پیامدهای آن را متهم می کنیم و در عین حال ، چیز بزرگ مطرود را دریافت می کنیم؟ پرواز کوتاه تر؟ در این مرحله ، بدن موظف است با کانتیکل ها ستایش کند ، به آنها گفت که او کار کل را رد می کند؟ برای این ارائه ها انتخاب شده است ، از وظایفی که از همان موارد مشابه دنبال می شود ، باید از بعضی موارد خاص پیروی کند. به عنوان مثال ، به عنوان مثال ، تقبیح او در صورت دریافت ، مگر اینکه در آنجا متولد شود ، با این حال ، آنها ناراحتی عمومی را که او از آنها متنفر است ، ترک کردند و به دنبال این مرد رفتند! چون نه. انتخاب زمان ، درد ما آسان است ، که من توضیح می دهم ، کسی که من بیایم به همین دلیل است. برای حال حاضر انتخاب شده است ، ما ممکن است قادر به رد کردن بسیاری از هیچ فرصتی برای فرار نیست ، خود ، خود ، هیچ چیزی برای عیب جویی از زحمت ، و در همان نفرت از حقیقت ، بیش از همه ، همه درد ناشی از انتخاب آنه</p>
            </div>
            <div class="audio">
                <audio controls>
                    <source src="/audio/Demons.mp3" type="audio/ogg">
                    <source src="/audio/Demons.mp3" type="audio/mpeg">
                    <source src="/audio/Demons.mp3" type="audio/wav">
                    سیستم شما توانایی خواندن این فایل را ندارد
                </audio>
            </div>
        </div>
    </main>

       <!-- Suggestion -->

       <section id="suggest">
        <div class="container">
            <h2 class="suggest-head">نظرات و پیشنهادات</h2>
            <div class="users">
                <div class="user">
                    <h4 class="username">ماهان</h4>
                    <p class="user-suggest">این پست یکی از بهترینای تاریخ بود خیلی لذت بردم</p>
                </div>

                <div class="user">
                    <h4 class="username">سعید</h4>
                    <p class="user-suggest">واقعا لذت بردم به شدت مشتاق برنامه های دیگتون هستم</p>
                </div>


                <div class="user">
                    <h4 class="username">جواد</h4>
                    <p class="user-suggest">مامان بیا منو بشور دیگه </p>
                </div>
            </div>
        </div>
    </section>


    <footer>
        <span class="line"></span>
         <div class="container-flex">
            <div class="info">
                <h3 class="info-text">info site</h3>
                <ul class="info-items">
                    <li class="info-item"><a href="#" class="info-link">Home</a></li>
                    <li class="info-item"><a href="#" class="info-link">Archive</a></li>
                    <li class="info-item"><a href="#" class="info-link">About us</a></li>
                    <li class="info-item"><a href="#" class="info-link">Contact us</a></li>
                </ul>
                <div class="social">
                    <ul class="social-items">
                        <li class="social-item"><i class="fab fa-facebook-f"></i></li>
                        <li class="social-item"><i class="fab fa-linkedin"></i></li>
                        <li class="social-item"><i class="fab fa-twitter"></i></li>
                    </ul>
                </div>
            </div>
            <div class="contact">
                <h3 class="contact-text">leave us a message</h3>
                <form class="form-contact">
                    <div class="form-flex">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Name">
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" placeholder="Email">
                        </div>
                    </div>
                    <div class="form-group">
                        <textarea rows="5" class="form-control" placeholder="How can i help you"></textarea>
                    </div>
                    <div class="form-submit">
                        <button class="submit">
                            Submit <span class="icon"><i class="fas fa-long-arrow-alt-right"></i></span>
                        </button>
                    </div>
                </form>
            </div>
         </div>
    </footer>

    <script>
        window.addEventListener("scroll",function(){
            var nav = document.querySelector("nav");
            nav.classList.toggle("sticky",window.scrollY > 0);
        })
    </script>

</body>
</html><?php /**PATH T:\PHP\php\shop\resources\views/Archive.blade.php ENDPATH**/ ?>