@include('Together.admin.layouts.header')


@yield('content')


@include('Together.admin.layouts.footer')
