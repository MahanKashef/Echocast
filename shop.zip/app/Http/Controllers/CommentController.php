<?php

namespace App\Http\Controllers;

use App\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;


class CommentController extends Controller
{
    public function index()
    {
        $comments = DB::table('comments')->get()->all();
        return view('Together.admin.comments.index',compact('comments',$comments));
    }

    public function show($id)
    {
        $comment = DB::table('comments')->where('id',$id)->get();
        return view('/admin/comment/show',compact('comment',$comment));
    }

    public function store($id,Request $request)
    {
        $user_id =  Auth::id();

        $comment = Comment::query()->create([
            'user_id'    => $user_id,
            'podcast_id' => $id,
            'comment'    => $request->get('comment'),
        ]);
        $comment->save();
        return redirect('/Archive/'.$id);
    }

    public function status($id)
    {
        $comment = DB::table('comments')->where('id',$id)->get();
        foreach($comment as $item);
        if($item->status=='approved')
        {
            DB::table('comments')->where('id',$id)->update(['status'=>'not_approved']);
            return redirect('/admin/comment');
        }
        else
        {
            DB::table('comments')->where('id',$id)->update(['status'=>'approved']);
            return redirect('/admin/comment');
        }
    }
}
