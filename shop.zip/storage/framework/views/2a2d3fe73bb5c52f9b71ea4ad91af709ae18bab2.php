
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/admin/bootstrap.min.css" >
    <title>Document</title>
</head>
<body>
    <h1>با سلام </h1>
    <h3> به سایت ما خوش آمدید</h3>
    <a role="button" class="btn btn-sm btn-success" href="http://127.0.0.1:8000/admin/check/<?php echo $verify; ?>">Verify</a>
</body>
</html>


<?php /**PATH T:\PHP\php\shop\resources\views/mails/mail.blade.php ENDPATH**/ ?>